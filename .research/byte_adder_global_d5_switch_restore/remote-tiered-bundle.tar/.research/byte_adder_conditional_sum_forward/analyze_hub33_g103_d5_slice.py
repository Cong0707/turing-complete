"""Reconstruct and audit Hub 33's serialized 103/5 ALU adder slice.

This is a read-only research tool.  The Hub circuit is not a standalone Byte
Adder: it consumes A/B plus precomputed AND/XOR/NOR/XNOR and block-propagate
signals.  The script preserves tristate/Z behavior across its 17/2 Custom
child, derives the live backward slice, and tests reviewed control hypotheses.
It never starts the game or writes the official save.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import sys
from typing import TypeAlias


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
sys.path.insert(0, str(PROJECT / "src"))

from tc_save_lab.analysis import wire_points  # noqa: E402
from tc_save_lab.codec import decode_circuit  # noqa: E402
from tc_save_lab.custom_design import design_position  # noqa: E402
from tc_save_lab.model import Circuit, Component  # noqa: E402
from tc_save_lab.pins import I, O, T, positioned_pins, rotate_offset  # noqa: E402


PARENT_PATH = (
    PROJECT
    / ".research"
    / "byte_adder_public"
    / "hub-33"
    / "dependencies"
    / "04"
    / "alu"
    / "32balu"
    / "extraction"
    / "2th add"
    / "circuit.data"
)
CHILD_PATH = (
    PROJECT
    / ".research"
    / "byte_adder_public"
    / "hub-33"
    / "dependencies"
    / "03"
    / "adders"
    / "subcomponents"
    / "3b 2d cla prep"
    / "circuit.data"
)
REPORT_PATH = HERE / "hub33_g103_d5_slice_report.json"

CUSTOM_KIND = 78
INPUT_KIND = 79
OUTPUT_KIND = 81
STATIC_INDEXER_KIND = 101
SPLITTER4_KIND = 110
CUSTOM_GRID_CENTER = (15, 15)

Value: TypeAlias = int | tuple[int, ...]


@dataclass(frozen=True)
class Pin:
    component_index: int
    name: str
    direction: str
    width: int
    position: tuple[int, int]


@dataclass(frozen=True)
class Drive:
    value: Value
    active: int


@dataclass(frozen=True)
class Compiled:
    circuit: Circuit
    pins: tuple[tuple[Pin, ...], ...]
    pin_network: dict[tuple[int, str], int]
    network_drivers: dict[int, tuple[Pin, ...]]
    network_receivers: dict[int, tuple[Pin, ...]]
    unconnected: tuple[Pin, ...]


@dataclass(frozen=True)
class Simulation:
    output_drives: dict[int, Drive]
    conflicts: dict[int, int]
    network_z: dict[int, int]


class UnionFind:
    def __init__(self, size: int) -> None:
        self.parent = list(range(size))

    def find(self, value: int) -> int:
        while self.parent[value] != value:
            self.parent[value] = self.parent[self.parent[value]]
            value = self.parent[value]
        return value

    def union(self, left: int, right: int) -> None:
        left = self.find(left)
        right = self.find(right)
        if left != right:
            self.parent[right] = left


def _custom_pins(
    component: Component,
    component_index: int,
    child: Circuit,
) -> tuple[Pin, ...]:
    widths = dict(component.custom_word_sizes)
    result: list[Pin] = []
    for port in child.components:
        if port.kind not in {INPUT_KIND, OUTPUT_KIND}:
            continue
        design_x, design_y = design_position(port.position)
        dx, dy = rotate_offset(
            (
                design_x - CUSTOM_GRID_CENTER[0],
                design_y - CUSTOM_GRID_CENTER[1],
            ),
            component.rotation,
        )
        result.append(
            Pin(
                component_index,
                f"port:{port.permanent_id}",
                I if port.kind == INPUT_KIND else O,
                widths.get(port.permanent_id, port.word_size),
                (component.position[0] + dx, component.position[1] + dy),
            )
        )
    return tuple(result)


def _ordinary_pins(
    component: Component,
    component_index: int,
    endpoint_positions: set[tuple[int, int]],
) -> tuple[Pin, ...]:
    if component.kind == STATIC_INDEXER_KIND:
        specs = (("in", I, (-2, 0), component.word_size), ("out", O, (2, 0), component.word_size))
        result = []
        for name, direction, offset, width in specs:
            dx, dy = rotate_offset(offset, component.rotation)
            result.append(
                Pin(
                    component_index,
                    name,
                    direction,
                    width,
                    (component.position[0] + dx, component.position[1] + dy),
                )
            )
        return tuple(result)

    if component.kind == SPLITTER4_KIND:
        specs = [("in", I, (-1, 0), 4)] + [
            (f"out{bit}", O, (1, bit - 1), 1) for bit in range(4)
        ]
        result = []
        for name, direction, offset, width in specs:
            dx, dy = rotate_offset(offset, component.rotation)
            result.append(
                Pin(
                    component_index,
                    name,
                    direction,
                    width,
                    (component.position[0] + dx, component.position[1] + dy),
                )
            )
        return tuple(result)

    if component.kind in {INPUT_KIND, OUTPUT_KIND}:
        candidates = {
            span: positioned_pins(component, component_index, foundry_port_span=span)
            for span in (1, 3)
        }
        connected = [
            span
            for span, pins in candidates.items()
            if pins and pins[0].position in endpoint_positions
        ]
        source = candidates[connected[0] if len(connected) == 1 else 3]
    else:
        source = positioned_pins(component, component_index)
    if not source:
        raise ValueError(f"unsupported component kind {component.kind} at {component_index}")
    return tuple(
        Pin(pin.component_index, pin.name, pin.direction, pin.width, pin.position)
        for pin in source
    )


def compile_circuit(circuit: Circuit, children: dict[int, Circuit]) -> Compiled:
    endpoints: list[tuple[tuple[int, int], tuple[int, int]]] = []
    owners: dict[tuple[int, int], list[int]] = defaultdict(list)
    for wire_index, wire in enumerate(circuit.wires):
        points = wire_points(wire)
        pair = (points[0], points[-1])
        endpoints.append(pair)
        owners[pair[0]].append(wire_index)
        owners[pair[1]].append(wire_index)

    union_find = UnionFind(len(circuit.wires))
    for wire_indices in owners.values():
        for wire_index in wire_indices[1:]:
            union_find.union(wire_indices[0], wire_index)
    network_at: dict[tuple[int, int], int] = {}
    for wire_index, pair in enumerate(endpoints):
        root = union_find.find(wire_index)
        network_at[pair[0]] = root
        network_at[pair[1]] = root

    endpoint_positions = set(network_at)
    pins: list[tuple[Pin, ...]] = []
    for component_index, component in enumerate(circuit.components):
        if component.kind == CUSTOM_KIND:
            try:
                component_pins = _custom_pins(
                    component,
                    component_index,
                    children[component.custom_id],
                )
            except KeyError as exc:
                raise ValueError(f"missing Custom child {component.custom_id}") from exc
        else:
            component_pins = _ordinary_pins(component, component_index, endpoint_positions)
        pins.append(component_pins)

    pin_network: dict[tuple[int, str], int] = {}
    drivers: dict[int, list[Pin]] = defaultdict(list)
    receivers: dict[int, list[Pin]] = defaultdict(list)
    unconnected: list[Pin] = []
    for component_pins in pins:
        for pin in component_pins:
            network = network_at.get(pin.position)
            if network is None:
                unconnected.append(pin)
                continue
            pin_network[(pin.component_index, pin.name)] = network
            if pin.direction in {O, T}:
                drivers[network].append(pin)
            else:
                receivers[network].append(pin)
    return Compiled(
        circuit,
        tuple(pins),
        pin_network,
        {network: tuple(values) for network, values in drivers.items()},
        {network: tuple(values) for network, values in receivers.items()},
        tuple(unconnected),
    )


def _zero_like(value: Value) -> Value:
    return 0 if isinstance(value, int) else tuple(0 for _ in value)


def _combine_drives(drives: tuple[Drive, ...], mask: int) -> tuple[Drive, int]:
    if not drives:
        return Drive(0, 0), 0
    active = 0
    conflict = 0
    first = drives[0].value
    if isinstance(first, int):
        value = 0
        for left_index, left in enumerate(drives):
            if not isinstance(left.value, int):
                raise ValueError("mixed scalar/word drivers")
            active |= left.active
            value |= left.active & left.value
            for right in drives[left_index + 1 :]:
                if not isinstance(right.value, int):
                    raise ValueError("mixed scalar/word drivers")
                conflict |= left.active & right.active & (left.value ^ right.value)
        return Drive(value & mask, active & mask), conflict & mask

    width = len(first)
    words: list[tuple[int, ...]] = []
    for drive in drives:
        if not isinstance(drive.value, tuple) or len(drive.value) != width:
            raise ValueError("incompatible word drivers")
        words.append(drive.value)
        active |= drive.active
    result = []
    for bit in range(width):
        bit_value = 0
        for left_index, left in enumerate(drives):
            bit_value |= left.active & words[left_index][bit]
            for right_index in range(left_index + 1, len(drives)):
                conflict |= (
                    left.active
                    & drives[right_index].active
                    & (words[left_index][bit] ^ words[right_index][bit])
                )
        result.append(bit_value & mask)
    return Drive(tuple(result), active & mask), conflict & mask


def _slice_word(value: Value, shift: int, width: int) -> Value:
    if isinstance(value, int):
        selected = (value,) if shift == 0 else (0,)
    else:
        selected = value[shift : shift + width]
        if len(selected) < width:
            selected += (0,) * (width - len(selected))
    if width == 1:
        return selected[0]
    return tuple(selected)


def simulate_packed(
    compiled: Compiled,
    compiled_children: dict[int, Compiled],
    source_values: dict[int, Value],
    mask: int,
) -> Simulation:
    circuit = compiled.circuit
    output_values: dict[tuple[int, str], Drive] = {}
    evaluated: set[int] = set()
    for component_index, value in source_values.items():
        pin = next(pin for pin in compiled.pins[component_index] if pin.direction in {O, T})
        output_values[(component_index, pin.name)] = Drive(value, mask)
        evaluated.add(component_index)

    conflicts: dict[int, int] = {}
    network_z: dict[int, int] = {}
    resolved: dict[int, Drive] = {}

    def resolve(network: int) -> Drive | None:
        if network in resolved:
            return resolved[network]
        drivers = compiled.network_drivers.get(network, ())
        if not drivers or not all(pin.component_index in evaluated for pin in drivers):
            return None
        values = tuple(output_values[(pin.component_index, pin.name)] for pin in drivers)
        drive, conflict = _combine_drives(values, mask)
        resolved[network] = drive
        conflicts[network] = conflict
        network_z[network] = mask ^ drive.active
        return drive

    pending = {
        index
        for index, component in enumerate(circuit.components)
        if component.kind not in {INPUT_KIND, OUTPUT_KIND}
    }
    while pending:
        progressed = False
        for component_index in tuple(pending):
            component = circuit.components[component_index]
            input_drives: dict[str, Drive] = {}
            for pin in compiled.pins[component_index]:
                if pin.direction != I:
                    continue
                network = compiled.pin_network.get((component_index, pin.name))
                if network is None:
                    break
                drive = resolve(network)
                if drive is None:
                    break
                input_drives[pin.name] = drive
            else:
                values = {name: drive.value for name, drive in input_drives.items()}
                outputs: dict[str, Drive]
                if component.kind in {4, 6, 7, 9}:
                    left = values["in0"]
                    right = values["in1"]
                    if not isinstance(left, int) or not isinstance(right, int):
                        raise ValueError(f"word reached scalar gate {component_index}")
                    if component.kind == 4:
                        result = left & right
                    elif component.kind == 6:
                        result = mask ^ (left & right)
                    elif component.kind == 7:
                        result = left | right
                    else:
                        result = mask ^ (left | right)
                    outputs = {"out": Drive(result & mask, mask)}
                elif component.kind == 12:
                    enable = values["enable"]
                    data = values["in"]
                    if not isinstance(enable, int) or not isinstance(data, int):
                        raise ValueError(f"word reached bit Switch {component_index}")
                    outputs = {"out": Drive(data, enable & mask)}
                elif component.kind == 16:
                    word = tuple(values[f"in{bit}"] for bit in range(8))
                    if not all(isinstance(value, int) for value in word):
                        raise ValueError("nested word reached Maker8")
                    outputs = {"out": Drive(word, mask)}
                elif component.kind == SPLITTER4_KIND:
                    source = values["in"]
                    if not isinstance(source, tuple):
                        source = (source, 0, 0, 0)
                    source = source + (0,) * (4 - len(source))
                    outputs = {
                        f"out{bit}": Drive(source[bit], mask) for bit in range(4)
                    }
                elif component.kind == STATIC_INDEXER_KIND:
                    shift = int(component.settings[0]) if component.settings else 0
                    outputs = {
                        "out": Drive(_slice_word(values["in"], shift, component.word_size), mask)
                    }
                elif component.kind == CUSTOM_KIND:
                    child = compiled_children[component.custom_id]
                    child_sources: dict[int, Value] = {}
                    for child_index, child_component in enumerate(child.circuit.components):
                        if child_component.kind != INPUT_KIND:
                            continue
                        child_sources[child_index] = values[f"port:{child_component.permanent_id}"]
                    child_result = simulate_packed(
                        child,
                        compiled_children,
                        child_sources,
                        mask,
                    )
                    outputs = {
                        f"port:{permanent_id}": drive
                        for permanent_id, drive in child_result.output_drives.items()
                    }
                    for network, conflict in child_result.conflicts.items():
                        if conflict:
                            conflicts[-(component_index + 1) * 1_000_000 - network] = conflict
                else:
                    raise ValueError(
                        f"unsupported evaluator kind {component.kind} at {component_index}"
                    )

                for name, drive in outputs.items():
                    output_values[(component_index, name)] = drive
                evaluated.add(component_index)
                pending.remove(component_index)
                progressed = True
        if not progressed:
            details = [
                (index, circuit.components[index].kind)
                for index in sorted(pending)
            ]
            raise ValueError(f"simulation stalled: {details}")

    output_drives: dict[int, Drive] = {}
    for component_index, component in enumerate(circuit.components):
        if component.kind != OUTPUT_KIND:
            continue
        pin = next(pin for pin in compiled.pins[component_index] if pin.direction == I)
        network = compiled.pin_network[(component_index, pin.name)]
        drive = resolve(network)
        if drive is None:
            raise ValueError(f"unresolved output component {component_index}")
        output_drives[component.permanent_id] = drive
    return Simulation(output_drives, conflicts, network_z)


def _truth_variable(bit: int, count: int) -> int:
    byte_count = count // 8
    if bit == 0:
        payload = bytes([0xAA]) * byte_count
    elif bit == 1:
        payload = bytes([0xCC]) * byte_count
    elif bit == 2:
        payload = bytes([0xF0]) * byte_count
    else:
        span = 1 << (bit - 3)
        block = bytes(span) + bytes([0xFF]) * span
        payload = block * (byte_count // len(block))
    return int.from_bytes(payload, "little")


def _ripple_expected(
    a_bits: tuple[int, ...],
    b_bits: tuple[int, ...],
    carry: int,
) -> tuple[tuple[int, ...], int]:
    sums = []
    current = carry
    for a_bit, b_bit in zip(a_bits, b_bits):
        propagate = a_bit ^ b_bit
        sums.append(propagate ^ current)
        current = (a_bit & b_bit) | (propagate & current)
    return tuple(sums), current


def _word(bits: tuple[int, ...], width: int, offset: int) -> tuple[int, ...]:
    if offset + len(bits) > width:
        raise ValueError("word placement out of range")
    return (0,) * offset + bits + (0,) * (width - offset - len(bits))


def _output_map(circuit: Circuit, simulation: Simulation) -> dict[str, Drive]:
    return {
        component.user_label: simulation.output_drives[component.permanent_id]
        for component in circuit.components
        if component.kind == OUTPUT_KIND
    }


def audit_child(
    compiled_child: Compiled,
    compiled_children: dict[int, Compiled],
) -> dict[str, object]:
    count = 128
    mask = (1 << count) - 1
    b = tuple(_truth_variable(bit, count) for bit in range(3))
    a = tuple(_truth_variable(3 + bit, count) for bit in range(3))
    n = _truth_variable(6, count)
    input_components = [
        (index, component)
        for index, component in enumerate(compiled_child.circuit.components)
        if component.kind == INPUT_KIND
    ]
    sources = {
        input_components[0][0]: b,
        input_components[1][0]: a,
        input_components[2][0]: n,
    }
    simulation = simulate_packed(compiled_child, compiled_children, sources, mask)
    outputs = _output_map(compiled_child.circuit, simulation)
    output_components = [
        component
        for component in compiled_child.circuit.components
        if component.kind == OUTPUT_KIND
    ]
    output_names = [component.user_label or "main" for component in output_components]
    expected_values = {
        "main": (a[2] | b[2]) & (n | (b[1] & (a[1] | a[0] | b[0])) | (a[1] & (a[0] | b[0]))),
        "ctrl 1": b[1] & (a[1] | a[0] | b[0]),
        "ctrl 2": a[1] & (a[0] | b[0]),
        "n or": a[2] | b[2],
    }
    rows = {}
    for component, name in zip(output_components, output_names):
        drive = simulation.output_drives[component.permanent_id]
        if not isinstance(drive.value, int):
            raise ValueError("child output unexpectedly word-valued")
        mismatch = drive.value ^ expected_values[name]
        rows[name] = {
            "function_mismatch_rows": mismatch.bit_count(),
            "active_rows": drive.active.bit_count(),
            "z_rows": (mask ^ drive.active).bit_count(),
            "one_rows": drive.value.bit_count(),
        }
    any_conflict = 0
    for conflict in simulation.conflicts.values():
        any_conflict |= conflict
    return {
        "enumerated_rows": count,
        "input_order": [
            {
                "permanent_id": component.permanent_id,
                "label": component.user_label,
                "word_size": component.word_size,
            }
            for _, component in input_components
        ],
        "outputs": rows,
        "conflict_rows": any_conflict.bit_count(),
        "reviewed_formulas": {
            "main": "(A2 OR B2) AND (n OR (B1 AND (A1 OR A0 OR B0)) OR (A1 AND (A0 OR B0)))",
            "ctrl 1": "B1 AND (A1 OR A0 OR B0), Z otherwise",
            "ctrl 2": "A1 AND (A0 OR B0), Z otherwise",
            "n or": "A2 OR B2",
        },
    }


def audit_parent_hypothesis(
    compiled_parent: Compiled,
    compiled_children: dict[int, Compiled],
) -> dict[str, object]:
    count = 1 << 17
    mask = (1 << count) - 1
    a_bits = tuple(_truth_variable(bit, count) for bit in range(8))
    b_bits = tuple(_truth_variable(8 + bit, count) for bit in range(8))
    carry = _truth_variable(16, count)
    a_word = _word(a_bits, 32, 8)
    b_word = _word(b_bits, 32, 8)
    and_word = tuple(left & right for left, right in zip(a_word, b_word))
    xor_word = tuple(left ^ right for left, right in zip(a_word, b_word))
    nor_word = tuple(mask ^ (left | right) for left, right in zip(a_word, b_word))
    xnor_bits = tuple(mask ^ (left ^ right) for left, right in zip(a_bits, b_bits))
    block_propagate = mask
    for bit in xor_word[8:16]:
        block_propagate &= bit

    external = {
        "A": a_word,
        "B": b_word,
        "AND": and_word,
        "XOR": xor_word,
        "NOR": nor_word,
        "XNOR": xnor_bits,
        "C": carry,
        "xor [7-15] and": block_propagate,
    }
    sources = {
        index: external[component.user_label]
        for index, component in enumerate(compiled_parent.circuit.components)
        if component.kind == INPUT_KIND
    }
    simulation = simulate_packed(compiled_parent, compiled_children, sources, mask)
    outputs = _output_map(compiled_parent.circuit, simulation)
    expected_sum, expected_carry = _ripple_expected(a_bits, b_bits, carry)
    _, expected_no_cin = _ripple_expected(a_bits, b_bits, 0)

    rows: dict[str, object] = {}
    for name, drive in outputs.items():
        z_rows = (mask ^ drive.active).bit_count()
        if name == "sum":
            if not isinstance(drive.value, tuple) or len(drive.value) != 8:
                raise ValueError("sum is not U8")
            mismatches = [
                (actual ^ expected).bit_count()
                for actual, expected in zip(drive.value, expected_sum)
            ]
            rows[name] = {
                "bit_mismatch_rows": mismatches,
                "all_bits_exact": all(value == 0 for value in mismatches),
                "z_rows": z_rows,
            }
        else:
            if not isinstance(drive.value, int):
                raise ValueError(f"{name} unexpectedly word-valued")
            expected = expected_carry if name == "cout" else expected_no_cin
            rows[name] = {
                "mismatch_rows": (drive.value ^ expected).bit_count(),
                "exact": drive.value == expected,
                "z_rows": z_rows,
                "one_rows": drive.value.bit_count(),
            }
    any_conflict = 0
    for conflict in simulation.conflicts.values():
        any_conflict |= conflict
    return {
        "enumerated_rows": count,
        "hypothesis": {
            "A/B placement": "local byte at source word bits 8..15",
            "AND": "A & B",
            "XOR": "A ^ B",
            "NOR": "NOT(A OR B)",
            "XNOR": "local NOT(A ^ B), bits 0..7",
            "xor [7-15] and": "AND-reduction of local XOR bits 8..15",
        },
        "outputs": rows,
        "conflict_rows": any_conflict.bit_count(),
    }


def component_cost(component: Component, children: dict[int, Circuit]) -> tuple[int, int]:
    if component.kind in {INPUT_KIND, OUTPUT_KIND, STATIC_INDEXER_KIND, SPLITTER4_KIND, 16}:
        return (0, 0)
    if component.kind in {4, 6, 7, 9}:
        return (1, 1)
    if component.kind == 12:
        return (2, 1)
    if component.kind == CUSTOM_KIND:
        child = children[component.custom_id]
        return (child.gate, child.delay)
    raise ValueError(f"missing reviewed cost for kind {component.kind}")


def derive_arrivals(
    compiled: Compiled,
    children: dict[int, Circuit],
    compiled_children: dict[int, Compiled],
    source_arrivals: dict[int, int] | None = None,
) -> tuple[dict[int, int], dict[tuple[int, str], int]]:
    """Return exact per-output arrivals, including output-specific Custom paths."""

    circuit = compiled.circuit
    source_arrivals = source_arrivals or {}
    pin_arrivals: dict[tuple[int, str], int] = {}
    evaluated: set[int] = set()
    for component_index, component in enumerate(circuit.components):
        if component.kind != INPUT_KIND:
            continue
        pin = next(pin for pin in compiled.pins[component_index] if pin.direction in {O, T})
        pin_arrivals[(component_index, pin.name)] = source_arrivals.get(component_index, 0)
        evaluated.add(component_index)

    def network_arrival(network: int) -> int | None:
        drivers = compiled.network_drivers.get(network, ())
        if not drivers or not all(pin.component_index in evaluated for pin in drivers):
            return None
        return max(pin_arrivals[(pin.component_index, pin.name)] for pin in drivers)

    pending = {
        index
        for index, component in enumerate(circuit.components)
        if component.kind not in {INPUT_KIND, OUTPUT_KIND}
    }
    while pending:
        progressed = False
        for component_index in tuple(pending):
            inputs = [
                (pin, compiled.pin_network.get((component_index, pin.name)))
                for pin in compiled.pins[component_index]
                if pin.direction == I
            ]
            if any(network is None for _, network in inputs):
                continue
            arrivals = {
                pin.name: network_arrival(int(network))
                for pin, network in inputs
            }
            if any(arrival is None for arrival in arrivals.values()):
                continue

            component = circuit.components[component_index]
            if component.kind == CUSTOM_KIND:
                child = compiled_children[component.custom_id]
                child_source_arrivals = {
                    child_index: int(arrivals[f"port:{child_component.permanent_id}"])
                    for child_index, child_component in enumerate(child.circuit.components)
                    if child_component.kind == INPUT_KIND
                }
                child_outputs, _ = derive_arrivals(
                    child,
                    {
                        custom_id: compiled_child.circuit
                        for custom_id, compiled_child in compiled_children.items()
                    },
                    compiled_children,
                    child_source_arrivals,
                )
                for child_component in child.circuit.components:
                    if child_component.kind != OUTPUT_KIND:
                        continue
                    pin_arrivals[
                        (component_index, f"port:{child_component.permanent_id}")
                    ] = child_outputs[child_component.permanent_id]
            else:
                output_pins = [
                    pin
                    for pin in compiled.pins[component_index]
                    if pin.direction in {O, T}
                ]
                output_arrival = max(
                    (int(value) for value in arrivals.values()),
                    default=0,
                ) + component_cost(component, children)[1]
                for pin in output_pins:
                    pin_arrivals[(component_index, pin.name)] = output_arrival
            evaluated.add(component_index)
            pending.remove(component_index)
            progressed = True
        if not progressed:
            raise ValueError(f"arrival derivation stalled: {sorted(pending)}")

    outputs: dict[int, int] = {}
    for component_index, component in enumerate(circuit.components):
        if component.kind != OUTPUT_KIND:
            continue
        pin = next(pin for pin in compiled.pins[component_index] if pin.direction == I)
        network = compiled.pin_network[(component_index, pin.name)]
        arrival = network_arrival(network)
        if arrival is None:
            raise ValueError(f"unresolved output arrival {component_index}")
        outputs[component.permanent_id] = arrival
    return outputs, pin_arrivals


def derive_cost_delay(
    compiled: Compiled,
    children: dict[int, Circuit],
    compiled_children: dict[int, Compiled],
) -> dict[str, object]:
    circuit = compiled.circuit
    output_by_id, pin_arrivals = derive_arrivals(
        compiled,
        children,
        compiled_children,
    )

    outputs = {
        component.user_label: output_by_id[component.permanent_id]
        for component in circuit.components
        if component.kind == OUTPUT_KIND
    }
    gate = sum(component_cost(component, children)[0] for component in circuit.components)
    delay = max(outputs.values(), default=0)
    return {
        "derived_gate": gate,
        "derived_delay": delay,
        "header_gate": circuit.gate,
        "header_delay": circuit.delay,
        "header_gate_matches": gate == circuit.gate,
        "header_delay_matches": delay == circuit.delay,
        "output_arrivals": outputs,
        "pin_arrivals": {
            f"{component}:{name}": arrival
            for (component, name), arrival in sorted(pin_arrivals.items())
        },
    }


def backward_slice(
    compiled: Compiled,
    children: dict[int, Circuit],
) -> dict[str, object]:
    circuit = compiled.circuit
    source_label_by_index = {
        index: component.user_label
        for index, component in enumerate(circuit.components)
        if component.kind == INPUT_KIND
    }

    per_output: dict[str, object] = {}
    all_live: set[int] = set()
    for output_index, output in enumerate(circuit.components):
        if output.kind != OUTPUT_KIND:
            continue
        live = {output_index}
        queue = deque([output_index])
        while queue:
            component_index = queue.popleft()
            for pin in compiled.pins[component_index]:
                if pin.direction != I:
                    continue
                network = compiled.pin_network.get((component_index, pin.name))
                if network is None:
                    continue
                for driver in compiled.network_drivers.get(network, ()):
                    if driver.component_index not in live:
                        live.add(driver.component_index)
                        queue.append(driver.component_index)
        all_live.update(live)
        counts = Counter(circuit.components[index].kind for index in live)
        gate = sum(component_cost(circuit.components[index], children)[0] for index in live)
        per_output[output.user_label] = {
            "live_component_count": len(live),
            "live_gate_before_external_leaves": gate,
            "kind_counts": {str(kind): count for kind, count in sorted(counts.items())},
            "external_labels": sorted(source_label_by_index[index] for index in live if index in source_label_by_index),
            "component_indices": sorted(live),
        }

    counts = Counter(circuit.components[index].kind for index in all_live)
    input_indexers: list[dict[str, object]] = []
    for index in sorted(all_live):
        component = circuit.components[index]
        if component.kind != STATIC_INDEXER_KIND:
            continue
        input_pin = next(pin for pin in compiled.pins[index] if pin.direction == I)
        network = compiled.pin_network.get((index, input_pin.name))
        labels = []
        if network is not None:
            labels = [
                source_label_by_index[pin.component_index]
                for pin in compiled.network_drivers.get(network, ())
                if pin.component_index in source_label_by_index
            ]
        input_indexers.append(
            {
                "component": index,
                "source_labels": sorted(labels),
                "shift": int(component.settings[0]) if component.settings else 0,
                "width": component.word_size,
            }
        )

    return {
        "all_outputs": {
            "live_component_count": len(all_live),
            "live_gate_before_external_leaves": sum(
                component_cost(circuit.components[index], children)[0]
                for index in all_live
            ),
            "dead_gate": circuit.gate
            - sum(
                component_cost(circuit.components[index], children)[0]
                for index in all_live
            ),
            "kind_counts": {str(kind): count for kind, count in sorted(counts.items())},
            "component_indices": sorted(all_live),
            "input_indexers": input_indexers,
        },
        "per_output": per_output,
    }


def _file_record(path: Path) -> dict[str, object]:
    payload = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(payload).hexdigest(),
        "bytes": len(payload),
        "format_version": payload[0],
    }


def main() -> None:
    parent = decode_circuit(PARENT_PATH.read_bytes())
    child = decode_circuit(CHILD_PATH.read_bytes())
    children = {child.custom_id: child}
    compiled_child = compile_circuit(child, {})
    compiled_parent = compile_circuit(parent, children)
    compiled_children = {child.custom_id: compiled_child}

    report = {
        "schema_version": 1,
        "official_save_modified": False,
        "game_started": False,
        "sources": {
            "parent": _file_record(PARENT_PATH),
            "child": _file_record(CHILD_PATH),
        },
        "parent_header": {
            "custom_id": parent.custom_id,
            "gate": parent.gate,
            "delay": parent.delay,
            "components": len(parent.components),
            "wires": len(parent.wires),
            "kind_counts": {
                str(kind): count
                for kind, count in sorted(Counter(c.kind for c in parent.components).items())
            },
        },
        "child_header": {
            "custom_id": child.custom_id,
            "gate": child.gate,
            "delay": child.delay,
            "components": len(child.components),
            "wires": len(child.wires),
            "kind_counts": {
                str(kind): count
                for kind, count in sorted(Counter(c.kind for c in child.components).items())
            },
        },
        "connectivity": {
            "parent_unconnected": [pin.__dict__ for pin in compiled_parent.unconnected],
            "child_unconnected": [pin.__dict__ for pin in compiled_child.unconnected],
        },
        "child_truth": audit_child(compiled_child, compiled_children),
        "cost_delay": {
            "child": derive_cost_delay(compiled_child, {}, compiled_children),
            "parent": derive_cost_delay(compiled_parent, children, compiled_children),
        },
        "backward_slice": backward_slice(compiled_parent, children),
        "reviewed_control_hypothesis": audit_parent_hypothesis(
            compiled_parent,
            compiled_children,
        ),
    }
    REPORT_PATH.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
