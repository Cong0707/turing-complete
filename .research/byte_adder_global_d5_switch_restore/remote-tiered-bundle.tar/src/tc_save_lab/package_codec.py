"""Strict, read-only decoder for current Turing Complete ``.pk`` packages."""

from __future__ import annotations

from dataclasses import dataclass

from .binary import FormatError, MAX_SEQUENCE_ITEMS, Reader
from .snappy import decompress_raw


PACKAGE_VERSION = 0
MAX_UNCOMPRESSED_SIZE = 100_000_000


@dataclass(frozen=True)
class PackageFile:
    name: str
    data: bytes


@dataclass(frozen=True)
class PackageDependency:
    path: str
    files: tuple[PackageFile, ...]


@dataclass(frozen=True)
class SchematicPackage:
    version: int
    level: str
    dependencies: tuple[PackageDependency, ...]
    main_files: tuple[PackageFile, ...]


def _read_files(reader: Reader) -> tuple[PackageFile, ...]:
    # The format stores the number of supplementary files. circuit.data is
    # always appended, so the serialized record count is extra_count + 1.
    count = reader.u16() + 1
    if count > MAX_SEQUENCE_ITEMS:
        raise FormatError(f"invalid package file count {count}")
    files: list[PackageFile] = []
    for _ in range(count):
        name = reader.string()
        files.append(PackageFile(name=name, data=reader.take(reader.u32())))
    return tuple(files)


def decode_package(payload: bytes) -> SchematicPackage:
    """Decode one package payload without writing any files.

    ``payload`` starts at the package version byte. Hub response framing is
    deliberately outside this codec because the same payload is also used by
    local ``.pk`` files.
    """

    if not payload:
        raise FormatError("empty package")
    version = payload[0]
    if version != PACKAGE_VERSION:
        raise FormatError(f"unsupported package version {version}")

    raw = decompress_raw(payload[1:])
    if len(raw) > MAX_UNCOMPRESSED_SIZE:
        raise FormatError(
            f"package expands to {len(raw)} bytes, limit is {MAX_UNCOMPRESSED_SIZE}"
        )
    reader = Reader(raw)
    level = reader.string()
    dependency_count = reader.u16()
    if dependency_count > MAX_SEQUENCE_ITEMS:
        raise FormatError(f"invalid package dependency count {dependency_count}")

    dependencies = tuple(
        PackageDependency(path=reader.string(), files=_read_files(reader))
        for _ in range(dependency_count)
    )
    main_files = _read_files(reader)
    reader.finish()
    return SchematicPackage(
        version=version,
        level=level,
        dependencies=dependencies,
        main_files=main_files,
    )
