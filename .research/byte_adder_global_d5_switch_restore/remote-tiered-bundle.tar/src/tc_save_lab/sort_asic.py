"""Build and prove a current-v15 streaming ASIC for Delicious Order.

The level receives sixteen U8 values through an Architecture Input and checks
sixteen ascending U8 values through an Architecture Output.  This module uses
a direct 16-stage insertion chain: the sixteenth input and the first output
share one tick, then fifteen 0xff flush values drain the chain.  It therefore
reaches the protocol lower bound of 31 ticks without relying on an old
architecture or an unreviewed custom component.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from hashlib import sha256
from heapq import heappop, heappush
import json
from pathlib import Path
import random
import re
from typing import Iterable, Sequence

from .analysis import wire_points
from .builder import stable_permanent_id, wire_from_vertices
from .codec import decode_v15, encode_v15
from .model import Circuit, Component, Point, Wire
from .pins import I, O, T, analyze_connectivity, positioned_pins, rotate_offset
from .simulate import SimulationError, simulate_clocked_trace
from .sprite_geometry import DEFAULT_COMPONENT_SPRITE_ROOT, sprite_alpha_cells


LEVEL = "sort"
ITEM_COUNT = 16
WORD_BITS = 8
WORD_MAX = (1 << WORD_BITS) - 1

# The Architecture Input has to read all sixteen values.  Its last read can
# feed the combinational insertion chain and the first correct Architecture
# Output in the same tick.  The remaining fifteen values take fifteen ticks.
EXPECTED_CYCLES = 31
FIRST_OUTPUT_TICK = ITEM_COUNT - 1

# These are the current minimum-gate component costs used by the candidate.
# They are kept explicit so a game-side cost change is visible in review.
LESS_U8_COST = (90, 4)
MUX_U8_COST = (33, 2)
WORD_DELAY_U8_COST = (40, 4)
BIT_DELAY_COST = (5, 4)
WORD_SWITCH_U8_COST = (16, 2)
NOT_BIT_COST = (1, 1)
EXPECTED_GATE = (
    ITEM_COUNT * LESS_U8_COST[0]
    + ITEM_COUNT * 2 * MUX_U8_COST[0]
    + ITEM_COUNT * WORD_DELAY_U8_COST[0]
    + ITEM_COUNT * BIT_DELAY_COST[0]
    + WORD_SWITCH_U8_COST[0]
    + NOT_BIT_COST[0]
)
# The current input reaches all sixteen compare/select stages in one tick;
# the phase shift chain is shorter than this direct insertion path.
EXPECTED_DELAY = ITEM_COUNT * (LESS_U8_COST[1] + MUX_U8_COST[1]) + WORD_DELAY_U8_COST[1]
PUBLIC_REFERENCE = (1654, 11, 32, 582208)

_SPRITE_NAME_BY_KIND = {
    2: "com_on.png",
    3: "com_not_bit.png",
    13: "com_delay_line_bit.png",
    25: "com_switch_word.png",
    27: "com_less_u.png",
    42: "com_mux.png",
    46: "com_constant.png",
    55: "com_delay_line_word.png",
    62: "com_level_input_switched.png",
    70: "com_level_output_switched.png",
}


@dataclass(frozen=True)
class SortCycle:
    """One direct insertion step, including the value expelled at chain end."""

    phase: str
    incoming: int
    expelled: int
    registers: tuple[int, ...]
    emits_output: bool


@dataclass
class SortScriptSession:
    """Exact event-level model of ``campaign/sort/test.si``.

    The game terminates the test after ``win``.  A caller that submits another
    output after that point is therefore outside the level's reachable flow and
    is rejected here instead of silently changing the evidence.
    """

    raw_numbers: tuple[int, ...]
    input_cursor: int = 0
    output_cursor: int = 0
    failure: str | None = None
    won: bool = False

    def __post_init__(self) -> None:
        if len(self.raw_numbers) != ITEM_COUNT:
            raise ValueError(f"expected {ITEM_COUNT} input values, got {len(self.raw_numbers)}")
        for value in self.raw_numbers:
            _check_byte(value)

    @property
    def sorted_numbers(self) -> tuple[int, ...]:
        return tuple(sorted(self.raw_numbers))

    def arch_get_input(self) -> int:
        if self.input_cursor >= ITEM_COUNT:
            return 0
        value = self.raw_numbers[self.input_cursor]
        self.input_cursor += 1
        return value

    def arch_check_output(self, output: int) -> bool:
        if self.won:
            raise RuntimeError("sort test has already returned win")
        _check_byte(output)
        expected = self.sorted_numbers[self.output_cursor]
        if output != expected:
            self.failure = (
                f"Index {self.output_cursor} in the sorted list should be "
                f"{expected}, not {output}"
            )
            return False
        if self.output_cursor == ITEM_COUNT - 1:
            self.won = True
            return True
        self.output_cursor += 1
        return True


def _check_byte(value: int) -> None:
    if not 0 <= value <= WORD_MAX:
        raise ValueError(f"value must be an unsigned byte, got {value}")


def current_test_script_contract(
    path: Path = Path(r"D:\Game\Steam\steamapps\common\Turing Complete\campaign\sort\test.si"),
) -> dict[str, object]:
    """Read and verify the active level-script clauses relied upon below."""

    text = path.read_text("utf-8", errors="strict")
    clauses = (
        r"raw_numbers = array\(<Int>, 16\)",
        r"sorted_numbers = array\(<Int>, 16\)",
        r"while i < 16",
        r"random\(0x100\)",
        r"sort\(\$sorted_numbers\)",
        r"if \.input_cursor >= 16",
        r"\.input_cursor \+= 1",
        r"if \.output_cursor == 15",
    )
    absent = [clause for clause in clauses if re.search(clause, text) is None]
    if absent:
        raise RuntimeError(f"sort test.si no longer matches the reviewed contract: {absent!r}")
    return {
        "path": str(path),
        "sha256": sha256(text.encode("utf-8")).hexdigest(),
        "item_count": ITEM_COUNT,
        "value_range": [0, WORD_MAX],
        "input_after_end": 0,
        "output_order": "ascending",
    }


def insertion_cycle(
    registers: Sequence[int], incoming: int
) -> tuple[tuple[int, ...], int]:
    """Apply one complete compare/select insertion pass through the chain."""

    if len(registers) != ITEM_COUNT:
        raise ValueError(f"expected {ITEM_COUNT} registers, got {len(registers)}")
    _check_byte(incoming)
    carry = incoming
    next_registers: list[int] = []
    for stored in registers:
        _check_byte(stored)
        if stored < carry:
            next_registers.append(carry)
            carry = stored
        else:
            next_registers.append(stored)
    return tuple(next_registers), carry


def sort_stream(values: Iterable[int]) -> tuple[tuple[int, ...], tuple[SortCycle, ...]]:
    """Model the candidate's 31-tick interface schedule exactly."""

    inputs = tuple(values)
    if len(inputs) != ITEM_COUNT:
        raise ValueError(f"expected {ITEM_COUNT} input values, got {len(inputs)}")
    for value in inputs:
        _check_byte(value)

    # The insertion chain is kept in descending order and starts with sixteen
    # sentinels above every legal U8 input.  Zero would silently discard any
    # first value greater than zero before the first real insertion.
    registers = (WORD_MAX,) * ITEM_COUNT
    outputs: list[int] = []
    trace: list[SortCycle] = []
    for index, value in enumerate(inputs):
        registers, expelled = insertion_cycle(registers, value)
        emits = index == ITEM_COUNT - 1
        if emits:
            outputs.append(expelled)
        trace.append(
            SortCycle(
                phase="load-output" if emits else "load",
                incoming=value,
                expelled=expelled,
                registers=registers,
                emits_output=emits,
            )
        )
    for _ in range(ITEM_COUNT - 1):
        registers, expelled = insertion_cycle(registers, WORD_MAX)
        outputs.append(expelled)
        trace.append(
            SortCycle(
                phase="flush",
                incoming=WORD_MAX,
                expelled=expelled,
                registers=registers,
                emits_output=True,
            )
        )
    return tuple(outputs), tuple(trace)


def _pin(component: Component, name: str) -> Point:
    matches = [pin.position for pin in positioned_pins(component) if pin.name == name]
    if len(matches) != 1:
        raise RuntimeError(f"component kind {component.kind} has no unique pin {name!r}")
    return matches[0]


def _component_cells(
    component: Component,
    *,
    sprite_root: Path,
) -> frozenset[Point]:
    try:
        name = _SPRITE_NAME_BY_KIND[component.kind]
    except KeyError as exc:
        raise RuntimeError(f"no reviewed sprite mapping for component kind {component.kind}") from exc
    path = sprite_root / name
    if not path.is_file():
        raise FileNotFoundError(f"missing current component sprite: {path}")
    return frozenset(
        (
            component.position[0] + rotate_offset(cell, component.rotation)[0],
            component.position[1] + rotate_offset(cell, component.rotation)[1],
        )
        for cell in sprite_alpha_cells(path)
    )


def _compress_route(points: list[Point]) -> tuple[Point, ...]:
    if len(points) < 2:
        raise RuntimeError("route has fewer than two points")
    vertices = [points[0]]
    previous_step: Point | None = None
    for start, end in zip(points, points[1:]):
        step = (end[0] - start[0], end[1] - start[1])
        if previous_step is not None and step != previous_step:
            vertices.append(start)
        previous_step = step
    vertices.append(points[-1])
    return tuple(vertices)


def _route_component_safe(
    source: Point,
    sink: Point,
    *,
    blocked: frozenset[Point],
    bounds: tuple[int, int, int, int],
) -> Wire:
    """A bounded low-memory orthogonal router for one endpoint pair.

    Wires are deliberately not obstacles.  They may cross in Turing Complete,
    while component alpha and every unrelated pin are hard obstacles.
    """

    if source == sink:
        raise RuntimeError(f"zero-length connection at {source}")
    min_x, max_x, min_y, max_y = bounds
    allowed = {source, sink}
    directions: tuple[Point, ...] = ((1, 0), (0, -1), (0, 1), (-1, 0))
    start = (source, -1)
    costs: dict[tuple[Point, int], int] = {start: 0}
    previous: dict[tuple[Point, int], tuple[Point, int] | None] = {start: None}
    queue: list[tuple[int, int, int, int, int]] = []
    heappush(
        queue,
        (abs(sink[0] - source[0]) + abs(sink[1] - source[1]), 0, source[0], source[1], -1),
    )
    target: tuple[Point, int] | None = None

    while queue:
        _, cost, x, y, direction_index = heappop(queue)
        state = ((x, y), direction_index)
        if cost != costs.get(state):
            continue
        if (x, y) == sink:
            target = state
            break
        for next_direction, (dx, dy) in enumerate(directions):
            point = (x + dx, y + dy)
            if not (min_x <= point[0] <= max_x and min_y <= point[1] <= max_y):
                continue
            if point in blocked and point not in allowed:
                continue
            next_cost = cost + 1 + (
                8 if direction_index >= 0 and direction_index != next_direction else 0
            )
            next_state = (point, next_direction)
            if next_cost >= costs.get(next_state, 1 << 60):
                continue
            costs[next_state] = next_cost
            previous[next_state] = state
            heuristic = abs(sink[0] - point[0]) + abs(sink[1] - point[1])
            heappush(
                queue,
                (next_cost + heuristic, next_cost, point[0], point[1], next_direction),
            )
    if target is None:
        raise RuntimeError(f"no component-safe route from {source} to {sink}")
    path: list[Point] = []
    state: tuple[Point, int] | None = target
    while state is not None:
        path.append(state[0])
        state = previous[state]
    path.reverse()
    return wire_from_vertices(_compress_route(path))


def _layout_obstacles(
    components: Sequence[Component],
    *,
    sprite_root: Path,
) -> tuple[frozenset[Point], tuple[int, int, int, int]]:
    alpha_owners: Counter[Point] = Counter()
    points: set[Point] = set()
    for index, component in enumerate(components):
        cells = _component_cells(component, sprite_root=sprite_root)
        alpha_owners.update(cells)
        points.update(cells)
        points.update(pin.position for pin in positioned_pins(component, index))
    overlaps = [point for point, count in alpha_owners.items() if count > 1]
    if overlaps:
        raise RuntimeError(f"component sprites overlap at {sorted(overlaps)!r}")
    if not points:
        raise RuntimeError("candidate has no geometry points")
    margin = 18
    xs = [point[0] for point in points]
    ys = [point[1] for point in points]
    return (
        frozenset(points),
        (min(xs) - margin, max(xs) + margin, min(ys) - margin, max(ys) + margin),
    )


def _route_connections(
    components: Sequence[Component],
    connections: Sequence[tuple[Point, Point]],
    *,
    sprite_root: Path,
) -> tuple[Wire, ...]:
    blocked, bounds = _layout_obstacles(components, sprite_root=sprite_root)
    return tuple(
        _route_component_safe(source, sink, blocked=blocked, bounds=bounds)
        for source, sink in connections
    )


def build_sort_asic(
    *,
    sprite_root: Path = DEFAULT_COMPONENT_SPRITE_ROOT,
) -> Circuit:
    """Build the 31-tick current-v15 direct insertion ASIC."""

    key = "architecture/codex-sort-v1"

    def component(role: str, kind: int, position: Point, **kwargs: object) -> Component:
        return Component(
            kind=kind,
            position=position,
            rotation=0,
            permanent_id=stable_permanent_id(key, role),
            **kwargs,
        )

    level_input = component(
        "level-input", 62, (-95, -20), word_size=WORD_BITS, ui_order=-2, user_label="sort-input"
    )
    level_output = component(
        "level-output", 70, (85, 480), word_size=WORD_BITS, ui_order=-2, user_label="sort-output"
    )
    one = component("one", 2, (-150, -12))
    phase_delays = tuple(
        component(f"phase-delay-{index}", 13, (-150, index * 32), init_data=0)
        for index in range(ITEM_COUNT)
    )
    not_phase = component("not-flush", 3, (-110, 510))
    constant_ff = component("constant-ff", 46, (-72, 520), word_size=WORD_BITS, init_data=WORD_MAX)
    flush_switch = component("flush-switch", 25, (-42, 520), word_size=WORD_BITS)

    delays = tuple(
        component(
            f"value-delay-{index}",
            55,
            (-20, index * 32),
            word_size=WORD_BITS,
            init_data=WORD_MAX,
        )
        for index in range(ITEM_COUNT)
    )
    less = tuple(
        component(f"less-{index}", 27, (0, index * 32), word_size=WORD_BITS)
        for index in range(ITEM_COUNT)
    )
    maximum = tuple(
        component(f"maximum-{index}", 42, (25, index * 32 - 7), word_size=WORD_BITS)
        for index in range(ITEM_COUNT)
    )
    minimum = tuple(
        component(f"minimum-{index}", 42, (25, index * 32 + 7), word_size=WORD_BITS)
        for index in range(ITEM_COUNT)
    )

    components = (
        level_input,
        level_output,
        one,
        *phase_delays,
        not_phase,
        constant_ff,
        flush_switch,
        *delays,
        *less,
        *maximum,
        *minimum,
    )

    connections: list[tuple[Point, Point]] = []

    def connect(source: Point, *sinks: Point) -> None:
        for sink in sinks:
            if source == sink:
                raise RuntimeError(f"attempted zero-length net at {source}")
            connections.append((source, sink))

    # A one-filled Delay Bit pipeline establishes three timing windows:
    # input reads t=1..16, first output at t=16, and 0xff flushing t>=17.
    connect(_pin(one, "out"), _pin(phase_delays[0], "in"))
    for earlier, later in zip(phase_delays, phase_delays[1:]):
        connect(_pin(earlier, "out"), _pin(later, "in"))
    connect(_pin(phase_delays[-1], "out"), _pin(not_phase, "in"), _pin(flush_switch, "enable"))
    connect(_pin(not_phase, "out"), _pin(level_input, "control"))
    connect(_pin(phase_delays[-2], "out"), _pin(level_output, "control"))
    connect(_pin(constant_ff, "out"), _pin(flush_switch, "in"))

    def carry_sinks(index: int) -> tuple[Point, Point, Point]:
        return (
            _pin(less[index], "in1"),
            _pin(maximum[index], "in1"),
            _pin(minimum[index], "in0"),
        )

    # The Input and the 0xff switch are both tri-state sources.  Their enables
    # are complements, so the common carry-0 net always has exactly one live
    # driver at runtime.
    connect(_pin(level_input, "value"), *carry_sinks(0))
    connect(_pin(flush_switch, "out"), *carry_sinks(0))

    for index in range(ITEM_COUNT):
        stored_sinks = [
            _pin(less[index], "in0"),
            _pin(maximum[index], "in0"),
            _pin(minimum[index], "in1"),
        ]
        connect(_pin(delays[index], "out"), *stored_sinks)
        connect(
            _pin(less[index], "out"),
            _pin(maximum[index], "select"),
            _pin(minimum[index], "select"),
        )
        connect(_pin(maximum[index], "out"), _pin(delays[index], "in"))
        if index < ITEM_COUNT - 1:
            connect(_pin(minimum[index], "out"), *carry_sinks(index + 1))

    # The final minimum is the first sorted value at the sixteenth load tick,
    # then one sorted value per 0xff flush tick.
    connect(_pin(minimum[-1], "out"), _pin(level_output, "value"))

    wires = _route_connections(components, connections, sprite_root=sprite_root)
    return Circuit(
        gate=EXPECTED_GATE,
        delay=EXPECTED_DELAY,
        clock_speed=100_000,
        description=(
            "Codex Sort ASIC v1: direct sixteen-stage insertion chain; "
            "last input and first sorted output share one tick"
        ),
        components=components,
        wires=wires,
    )


def audit_sort_layout(
    circuit: Circuit,
    *,
    sprite_root: Path = DEFAULT_COMPONENT_SPRITE_ROOT,
) -> dict[str, object]:
    """Apply the game sprite alpha and all reviewed pins to every route."""

    alpha_owners: dict[Point, list[int]] = {}
    pin_owners: dict[Point, list[tuple[int, str]]] = {}
    unsupported: list[int] = []
    for index, component in enumerate(circuit.components):
        if component.kind not in _SPRITE_NAME_BY_KIND:
            unsupported.append(component.kind)
            continue
        for point in _component_cells(component, sprite_root=sprite_root):
            alpha_owners.setdefault(point, []).append(index)
        for pin in positioned_pins(component, index):
            pin_owners.setdefault(pin.position, []).append((index, pin.name))

    body_contacts: list[tuple[int, int, Point]] = []
    interior_pin_contacts: list[tuple[int, int, Point, str]] = []
    for wire_index, wire in enumerate(circuit.wires):
        points = wire_points(wire)
        endpoints = {points[0], points[-1]}
        for point in points:
            for component_index in alpha_owners.get(point, ()):
                valid_endpoint = point in endpoints and any(
                    owner == component_index for owner, _ in pin_owners.get(point, ())
                )
                if not valid_endpoint:
                    body_contacts.append((wire_index, component_index, point))
            if point in endpoints:
                continue
            for component_index, name in pin_owners.get(point, ()):
                interior_pin_contacts.append((wire_index, component_index, point, name))

    return {
        "sprite_files": sorted({_SPRITE_NAME_BY_KIND[component.kind] for component in circuit.components if component.kind in _SPRITE_NAME_BY_KIND}),
        "unsupported_component_kinds": sorted(set(unsupported)),
        "component_overlap_count": sum(
            len(owners) - 1 for owners in alpha_owners.values() if len(owners) > 1
        ),
        "wire_component_contact_count": len(body_contacts),
        "wire_interior_pin_contact_count": len(interior_pin_contacts),
        "wire_component_contacts": [
            {"wire": wire, "component": component, "point": list(point)}
            for wire, component, point in body_contacts
        ],
        "wire_interior_pin_contacts": [
            {"wire": wire, "component": component, "point": list(point), "pin": name}
            for wire, component, point, name in interior_pin_contacts
        ],
    }


def simulate_sort_case(
    circuit: Circuit,
    values: Sequence[int],
) -> tuple[tuple[int, ...], tuple[SortCycle, ...]]:
    """Replay one complete candidate run through the exact callback model."""

    inputs = tuple(values)
    if len(inputs) != ITEM_COUNT:
        raise ValueError(f"expected {ITEM_COUNT} input values, got {len(inputs)}")
    for value in inputs:
        _check_byte(value)
    session = SortScriptSession(inputs)
    trace = simulate_clocked_trace(
        circuit,
        inputs=tuple(
            {"sort-input": inputs[tick] if tick < ITEM_COUNT else 0}
            for tick in range(EXPECTED_CYCLES)
        ),
    )
    outputs: list[int] = []
    cycles: list[SortCycle] = []
    for tick, result in enumerate(trace):
        if tick < ITEM_COUNT:
            incoming = session.arch_get_input()
        else:
            incoming = session.arch_get_input()
        output = result.outputs.get("sort-output")
        if output is not None:
            if not session.arch_check_output(output):
                raise RuntimeError(session.failure or "sort output rejected")
            outputs.append(output)
        phase = "load" if tick < FIRST_OUTPUT_TICK else "load-output" if tick == FIRST_OUTPUT_TICK else "flush"
        cycles.append(
            SortCycle(
                phase=phase,
                incoming=incoming,
                expelled=output if output is not None else -1,
                registers=(),
                emits_output=output is not None,
            )
        )
    if not session.won:
        raise RuntimeError(
            f"sort candidate did not win: inputs={session.input_cursor}, outputs={session.output_cursor}, failure={session.failure!r}"
        )
    if len(outputs) != ITEM_COUNT:
        raise RuntimeError(f"sort candidate emitted {len(outputs)} values, expected {ITEM_COUNT}")
    return tuple(outputs), tuple(cycles)


def verify_sort_asic(
    circuit: Circuit | None = None,
    *,
    sprite_root: Path = DEFAULT_COMPONENT_SPRITE_ROOT,
    random_case_count: int = 128,
) -> dict[str, object]:
    """Verify protocol timing, arithmetic, v15 encoding, and route geometry."""

    if random_case_count < 0:
        raise ValueError("random_case_count must not be negative")
    candidate = build_sort_asic(sprite_root=sprite_root) if circuit is None else circuit
    if (candidate.gate, candidate.delay) != (EXPECTED_GATE, EXPECTED_DELAY):
        raise RuntimeError("sort candidate metric header changed")
    if len(candidate.components) != 86:
        raise RuntimeError(f"sort candidate component count changed: {len(candidate.components)}")
    if sum(component.kind == 62 for component in candidate.components) != 1:
        raise RuntimeError("sort candidate requires exactly one Architecture Input")
    if sum(component.kind == 70 for component in candidate.components) != 1:
        raise RuntimeError("sort candidate requires exactly one Architecture Output")

    connectivity = analyze_connectivity(candidate)
    for field in (
        "unsupported_component_kind_counts",
        "unconnected_pin_count",
        "multi_driver_network_count",
        "undriven_network_count",
        "sinkless_network_count",
        "width_mismatch_network_count",
        "cycle_component_count",
    ):
        if connectivity[field]:
            raise RuntimeError(f"sort candidate connectivity failure {field}: {connectivity[field]!r}")

    layout = audit_sort_layout(candidate, sprite_root=sprite_root)
    for field in (
        "unsupported_component_kinds",
        "component_overlap_count",
        "wire_component_contact_count",
        "wire_interior_pin_contact_count",
    ):
        if layout[field]:
            raise RuntimeError(f"sort candidate geometry failure {field}: {layout[field]!r}")

    cases = [
        [0] * ITEM_COUNT,
        [WORD_MAX] * ITEM_COUNT,
        list(range(ITEM_COUNT)),
        list(range(ITEM_COUNT - 1, -1, -1)),
        [0, WORD_MAX] * (ITEM_COUNT // 2),
        [7, 7, 3, 3, WORD_MAX, 0, 7, 3, 128, 128, 1, 1, 254, 2, 2, 2],
    ]
    generator = random.Random(0xC0D3)
    cases.extend(
        [generator.randrange(WORD_MAX + 1) for _ in range(ITEM_COUNT)]
        for _ in range(random_case_count)
    )
    for values in cases:
        reference_outputs, reference_trace = sort_stream(values)
        if reference_outputs != tuple(sorted(values)):
            raise RuntimeError(f"reference insertion model failed for {values!r}")
        if len(reference_trace) != EXPECTED_CYCLES:
            raise RuntimeError("reference tick count regressed")
        try:
            outputs, runtime_trace = simulate_sort_case(candidate, values)
        except SimulationError as exc:
            raise RuntimeError(f"candidate simulator rejected sort case {values!r}") from exc
        if outputs != tuple(sorted(values)):
            raise RuntimeError(f"candidate output mismatch: values={values!r}, outputs={outputs!r}")
        if len(runtime_trace) != EXPECTED_CYCLES:
            raise RuntimeError("candidate runtime tick count regressed")

    payload = encode_v15(candidate)
    if decode_v15(payload) != candidate:
        raise RuntimeError("sort candidate failed v15 round trip")
    return {
        "gate": candidate.gate,
        "delay": candidate.delay,
        "cycles": EXPECTED_CYCLES,
        "energy": candidate.gate * candidate.delay * EXPECTED_CYCLES,
        "leaderboard_tuple": [candidate.gate, candidate.delay, EXPECTED_CYCLES],
        "public_reference": list(PUBLIC_REFERENCE),
        "component_count": len(candidate.components),
        "wire_count": len(candidate.wires),
        "component_kind_counts": {
            str(kind): count for kind, count in sorted(Counter(component.kind for component in candidate.components).items())
        },
        "tested_case_count": len(cases),
        "connectivity": connectivity,
        "layout": layout,
    }


def write_sort_asic_candidate(
    project_root: Path,
    *,
    sprite_root: Path = DEFAULT_COMPONENT_SPRITE_ROOT,
    random_case_count: int = 128,
) -> dict[str, object]:
    """Emit only the reviewable candidate artifact; never touch a live save."""

    project_root = Path(project_root)
    candidate = build_sort_asic(sprite_root=sprite_root)
    verification = verify_sort_asic(
        candidate,
        sprite_root=sprite_root,
        random_case_count=random_case_count,
    )
    payload = encode_v15(candidate)
    destination = project_root / "examples" / LEVEL / "candidate" / "circuit.data"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(payload)
    (destination.parent / ".gitkeep").unlink(missing_ok=True)

    script: dict[str, object] | None = None
    try:
        script = current_test_script_contract()
    except FileNotFoundError:
        # The artifact remains reproducible on a non-Windows checkout; runtime
        # verification of the live campaign script is intentionally reported.
        script = None
    metadata = {
        "schema": 1,
        "level": LEVEL,
        "title": "Delicious Order",
        "title_zh": "美味排行",
        "strategy": "16-stage direct insertion chain; t16 last-input plus first-output; 15 x 0xff flush",
        "deployment_target": "schematics/architecture/CODEX-SORT/circuit.data",
        "format_version": 15,
        "sha256": sha256(payload).hexdigest(),
        "game_validation": "pending: no game process was started by this generator",
        "test_script_contract": script,
        **verification,
    }
    metadata_path = destination.parent / "metadata.json"
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return metadata
