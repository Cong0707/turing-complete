"""非原生 U8 除法器候选。

``campaign/byte_divide`` 会在通关后解锁 ``com_div``，因此不能把它作为本关
解法。这里使用 restoring division 的组合结构，只使用已经存在的普通门和
字级元件：Splitter8、Maker8、LessU、Negator、Adder、Mux、Equal、Not。

本模块只生成项目候选，不启动游戏，也不修改正式存档。头部计分先保留为
``0/0``，让游戏在实际载入后重新计算；这比伪造原生 ``370/32`` 更可靠。
"""

from __future__ import annotations

from collections import defaultdict
from heapq import heappop, heappush
from hashlib import sha256
import json
from pathlib import Path

from .analysis import wire_points
from .builder import stable_permanent_id, wire_from_vertices
from .codec import decode_v15, encode_v15
from .model import Circuit, Component, Point
from .pins import I, O, T, analyze_connectivity, positioned_pins
from .simulate import simulate_combinational
from .sprite_geometry import DEFAULT_COMPONENT_SPRITE_ROOT, audit_sprite_geometry, sprite_alpha_cells


LEVEL = "byte_divide"
WORD_SIZE = 8
TEST_TICK_COUNT = 0x1_0000

INPUT_KIND = 61
OUTPUT_KIND = 69
SPLITTER_KIND = 17
MAKER_KIND = 16
NOT_BIT_KIND = 3
AND_WORD_KIND = 20
EQUAL_KIND = 26
LESS_U_KIND = 27
NEGATOR_KIND = 29
ADDER_KIND = 30
MUX_KIND = 42
CONSTANT_KIND = 46
ZERO_BIT_KIND = 1


def evaluate_byte_divide(dividend: int, divisor: int) -> int:
    """关卡定义的无符号 U8 商，除数为零时返回零。"""

    if not 0 <= dividend <= 0xFF or not 0 <= divisor <= 0xFF:
        raise ValueError(f"Byte Divide expects U8 inputs, got {dividend}, {divisor}")
    return 0 if divisor == 0 else dividend // divisor


def test_input_at(tick: int) -> tuple[int, int]:
    """重放当前安装版 byte_divide/test.si 的输入发生器。"""

    if not 0 <= tick < TEST_TICK_COUNT:
        raise ValueError(f"tick must be in [0, {TEST_TICK_COUNT}), got {tick}")
    value = tick + 0xFFB0
    value ^= value << 7
    value ^= value >> 9
    value ^= value << 8
    return ((value >> 8) & 0xFF, value & 0xFF)


def _immutable_components(project_root: Path) -> tuple[Component, ...]:
    path = Path(project_root) / "examples" / LEVEL / "scaffold" / "immutable.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    records = []
    for raw in data["immutable_components"]:
        record = dict(raw)
        record.pop("role", None)
        records.append(record)
    components = Circuit.from_dict({"components": records}).components
    if len(components) != 3 or tuple(c.user_label for c in components) != ("A", "B", "Result"):
        raise ValueError("byte_divide scaffold must contain A, B and Result")
    return components


def _component(level: str, name: str, kind: int, position: Point, *, word_size: int = 1, init_data: int = 0) -> Component:
    return Component(
        kind=kind,
        position=position,
        rotation=0,
        permanent_id=stable_permanent_id(level, name),
        word_size=word_size,
        init_data=init_data,
    )


def _local_footprint(component: Component, sprite_root: Path) -> frozenset[Point]:
    names = {
        1: "com_off.png",
        3: "com_not_bit.png",
        16: "com_maker_bit_8.png",
        17: "com_splitter_bit_8.png",
        20: "com_and_word.png",
        26: "com_equal.png",
        27: "com_less_u.png",
        29: "com_neg.png",
        30: "com_add.png",
        42: "com_mux.png",
        46: "com_constant.png",
        61: "com_level_input_word.png",
        69: "com_level_output_word.png",
    }
    path = sprite_root / names[component.kind]
    cells = sprite_alpha_cells(path)
    return frozenset(
        (component.position[0] + x, component.position[1] + y)
        for x, y in cells
    )


def _pin_map(components: tuple[Component, ...]) -> dict[tuple[int, str], Point]:
    return {
        (index, pin.name): pin.position
        for index, component in enumerate(components)
        for pin in positioned_pins(component, index)
    }


def _outward_cells(
    component: Component,
    pin_position: Point,
    direction: str,
    footprint: frozenset[Point],
) -> frozenset[Point]:
    """保留一个从端口向外的合法接近走廊。"""

    step = (1, 0) if direction in {O, T} else (-1, 0)
    result: set[Point] = {pin_position}
    point = pin_position
    for _ in range(8):
        point = (point[0] + step[0], point[1] + step[1])
        result.add(point)
        if point not in footprint:
            break
    return frozenset(result)


def _route(
    source: Point,
    destination: Point,
    *,
    components: tuple[Component, ...],
    pin_positions: dict[tuple[int, str], Point],
    source_component: int,
    destination_component: int,
    occupied: set[Point],
    sprite_root: Path,
) -> tuple[Point, ...]:
    """在当前元件和既有导线之间寻找一条不重叠的正交线路。"""

    if source == destination:
        raise RuntimeError(f"zero-length connection at {source}")
    footprints = tuple(_local_footprint(component, sprite_root) for component in components)
    blocked = set().union(*footprints)
    all_pin_positions = set(pin_positions.values())
    blocked.update(all_pin_positions)
    source_footprint = footprints[source_component]
    destination_footprint = footprints[destination_component]
    allowed = _outward_cells(components[source_component], source, O, source_footprint)
    allowed |= _outward_cells(components[destination_component], destination, I, destination_footprint)
    blocked.difference_update(allowed)
    # Wire crossings are legal in the current editor; only overlapping long
    # segments are undesirable.  Treat existing wire cells as a routing
    # penalty instead of a hard wall so one early bus cannot cut the board in
    # half and make later fan-out impossible.

    footprint_points = tuple(point for footprint in footprints for point in footprint)
    min_x = min(min(point[0] for point in footprint_points), source[0], destination[0]) - 18
    max_x = max(max(point[0] for point in footprint_points), source[0], destination[0]) + 18
    min_y = min(min(point[1] for point in footprint_points), source[1], destination[1]) - 18
    max_y = max(max(point[1] for point in footprint_points), source[1], destination[1]) + 18
    min_x, max_x = max(-245, min_x), min(245, max_x)
    min_y, max_y = max(-245, min_y), min(245, max_y)

    # A* state includes the previous direction so that the generated wiring
    # stays readable without adding diagonal segments.
    queue: list[tuple[int, int, Point, int]] = []
    counter = 0
    heappush(queue, (0, counter, source, -1))
    costs: dict[tuple[Point, int], int] = {(source, -1): 0}
    parents: dict[tuple[Point, int], tuple[Point, int] | None] = {(source, -1): None}
    directions = ((1, 0), (0, 1), (-1, 0), (0, -1))
    end_state: tuple[Point, int] | None = None
    while queue:
        _, _, point, previous_direction = heappop(queue)
        state = (point, previous_direction)
        cost = costs[state]
        if point == destination:
            end_state = state
            break
        for direction_index, (dx, dy) in enumerate(directions):
            next_point = (point[0] + dx, point[1] + dy)
            if not (min_x <= next_point[0] <= max_x and min_y <= next_point[1] <= max_y):
                continue
            if next_point in blocked and next_point not in {source, destination}:
                continue
            turn = 0 if previous_direction < 0 or previous_direction == direction_index else 5
            wire_penalty = 20 if next_point in occupied and next_point not in {source, destination} else 0
            next_cost = cost + 1 + turn + wire_penalty
            next_state = (next_point, direction_index)
            if next_cost >= costs.get(next_state, 1 << 60):
                continue
            costs[next_state] = next_cost
            parents[next_state] = state
            counter += 1
            heuristic = abs(next_point[0] - destination[0]) + abs(next_point[1] - destination[1])
            heappush(queue, (next_cost + heuristic, counter, next_point, direction_index))
    if end_state is None:
        raise RuntimeError(f"no safe route from {source} to {destination}")
    points: list[Point] = []
    state: tuple[Point, int] | None = end_state
    while state is not None:
        points.append(state[0])
        state = parents[state]
    points.reverse()
    compressed: list[Point] = [points[0]]
    for point in points[1:]:
        if len(compressed) >= 2:
            ax, ay = compressed[-2]
            bx, by = compressed[-1]
            cx, cy = point
            if (bx - ax, by - ay) == (cx - bx, cy - by):
                compressed[-1] = point
                continue
        compressed.append(point)
    return tuple(compressed)


def _connect(
    wires: list,
    occupied: set[Point],
    vertices: tuple[Point, ...],
) -> None:
    wire = wire_from_vertices(vertices)
    wires.append(wire)
    occupied.update(wire_points(wire))


def build_byte_divide_gate_circuit(
    project_root: Path,
    *,
    sprite_root: Path = DEFAULT_COMPONENT_SPRITE_ROOT,
) -> Circuit:
    """构造不含 ``com_div`` 的 restoring divider。"""

    immutable = _immutable_components(project_root)
    components: list[Component] = list(immutable)
    labels = {component.user_label: index for index, component in enumerate(components)}
    a_index, b_index, output_index = labels["A"], labels["B"], labels["Result"]

    # Eight rows hold one restoring stage each.  The sparse spacing leaves a
    # complete cell between the current sprite bodies and gives the router
    # room to approach every port from the left/right side.
    rows = tuple(-42 + 12 * stage for stage in range(8))
    a_split = len(components)
    components.append(_component(LEVEL, "input-splitter", SPLITTER_KIND, (-12, 0), word_size=8))
    zero_word = len(components)
    components.append(_component(LEVEL, "zero-word", CONSTANT_KIND, (-12, 72), word_size=8, init_data=0))
    zero_bit = len(components)
    components.append(_component(LEVEL, "zero-bit", ZERO_BIT_KIND, (-12, 84)))
    neg_b = len(components)
    components.append(_component(LEVEL, "negate-divisor", NEGATOR_KIND, (4, 72), word_size=8))
    equal_zero = len(components)
    components.append(_component(LEVEL, "divisor-zero-test", EQUAL_KIND, (24, 80), word_size=8))

    stage_indices: list[dict[str, int]] = []
    for stage, row in enumerate(rows):
        rem_split = len(components)
        components.append(_component(LEVEL, f"stage-{stage}-remainder-splitter", SPLITTER_KIND, (0, row), word_size=8))
        pre_maker = len(components)
        components.append(_component(LEVEL, f"stage-{stage}-partial-maker", MAKER_KIND, (16, row), word_size=8))
        less = len(components)
        components.append(_component(LEVEL, f"stage-{stage}-less", LESS_U_KIND, (34, row - 4), word_size=8))
        subtract = len(components)
        components.append(_component(LEVEL, f"stage-{stage}-subtract", ADDER_KIND, (34, row + 4), word_size=8))
        select = len(components)
        components.append(_component(LEVEL, f"stage-{stage}-remainder-mux", MUX_KIND, (52, row), word_size=8))
        quotient_not = len(components)
        components.append(
            _component(
                LEVEL,
                f"stage-{stage}-quotient-bit",
                NOT_BIT_KIND,
                (64, row),
            )
        )
        stage_indices.append({"rem_split": rem_split, "pre_maker": pre_maker, "less": less, "subtract": subtract, "select": select, "qnot": quotient_not})

    quotient_maker = len(components)
    components.append(_component(LEVEL, "quotient-maker", MAKER_KIND, (82, 0), word_size=8))
    final_mux = len(components)
    components.append(_component(LEVEL, "zero-divisor-mux", MUX_KIND, (100, 0), word_size=8))

    component_tuple = tuple(components)
    pins = _pin_map(component_tuple)
    wires: list = []
    occupied: set[Point] = set()

    def connect(source_component: int, source_pin: str, destination_component: int, destination_pin: str) -> None:
        source = pins[(source_component, source_pin)]
        destination = pins[(destination_component, destination_pin)]
        vertices = _route(
            source,
            destination,
            components=component_tuple,
            pin_positions=pins,
            source_component=source_component,
            destination_component=destination_component,
            occupied=occupied,
            sprite_root=sprite_root,
        )
        _connect(wires, occupied, vertices)

    # U8 A enters one splitter; divisor B fans out to every stage.
    connect(a_index, "value", a_split, "in")
    connect(b_index, "value", neg_b, "in")
    connect(b_index, "value", equal_zero, "in0")
    connect(zero_word, "out", equal_zero, "in1")

    # The first remainder is zero; later remainders come from the previous mux.
    connect(zero_word, "out", stage_indices[0]["rem_split"], "in")
    for stage in range(1, 8):
        connect(stage_indices[stage - 1]["select"], "out", stage_indices[stage]["rem_split"], "in")

    # Each stage builds pre = (remainder << 1) | next dividend bit, compares it
    # with B, subtracts B in parallel, and selects the restored remainder.
    for stage, indices in enumerate(stage_indices):
        rem_split = indices["rem_split"]
        pre_maker = indices["pre_maker"]
        less = indices["less"]
        subtract = indices["subtract"]
        select = indices["select"]
        quotient_not = indices["qnot"]
        connect(a_split, f"out{7 - stage}", pre_maker, "in0")
        for bit in range(7):
            connect(rem_split, f"out{bit}", pre_maker, f"in{bit + 1}")
        connect(pre_maker, "out", less, "in0")
        connect(b_index, "value", less, "in1")
        connect(pre_maker, "out", subtract, "in0")
        connect(neg_b, "out", subtract, "in1")
        connect(zero_bit, "out", subtract, "carry_in")
        # Less=1 means pre<B, so Mux(select=less, in0=diff, in1=pre)
        # restores the partial remainder without an extra inverter.
        connect(less, "out", select, "select")
        connect(subtract, "out", select, "in0")
        connect(pre_maker, "out", select, "in1")
        connect(less, "out", quotient_not, "in")

    for stage, indices in enumerate(stage_indices):
        connect(indices["qnot"], "out", quotient_maker, f"in{7 - stage}")
    connect(quotient_maker, "out", final_mux, "in0")
    connect(equal_zero, "out", final_mux, "select")
    connect(zero_word, "out", final_mux, "in1")
    connect(final_mux, "out", output_index, "value")

    return Circuit(
        gate=0,
        delay=0,
        clock_speed=20_000_000,
        description="Codex 非原生 U8 restoring 除法器；不使用 com_div。",
        components=component_tuple,
        wires=tuple(wires),
    )


def verify_byte_divide_gate_circuit(
    circuit: Circuit,
    *,
    sprite_root: Path = DEFAULT_COMPONENT_SPRITE_ROOT,
) -> dict[str, object]:
    """全 U8 语义、脚本流、v15、拓扑和当前精灵几何审计。"""

    forbidden = {32, 31, 108}
    forbidden_present = sorted({component.kind for component in circuit.components} & forbidden)
    if forbidden_present:
        raise RuntimeError(f"非原生除法器包含被禁止的原生算术元件：{forbidden_present}")
    connectivity = analyze_connectivity(circuit)
    for field in (
        "unsupported_component_kind_counts",
        "unconnected_pin_count",
        "multi_driver_network_count",
        "undriven_network_count",
        "width_mismatch_network_count",
        "cycle_component_count",
    ):
        if connectivity[field]:
            raise RuntimeError(f"Byte Divide topology failure {field}: {connectivity[field]}")
    layout = audit_sprite_geometry(circuit, sprite_root)
    for field in ("unsupported_component_kinds", "component_overlap_cells", "wire_collisions", "wire_interior_pin_contacts"):
        if getattr(layout, field):
            raise RuntimeError(f"Byte Divide geometry failure {field}: {getattr(layout, field)}")

    vectors = 0
    for dividend in range(256):
        for divisor in range(256):
            outputs = simulate_combinational(circuit, {"A": dividend, "B": divisor})
            if outputs.get("Result") != evaluate_byte_divide(dividend, divisor):
                raise RuntimeError(f"truth-table mismatch for A={dividend}, B={divisor}: {outputs}")
            vectors += 1
    stream_vectors = 0
    for tick in range(TEST_TICK_COUNT):
        dividend, divisor = test_input_at(tick)
        outputs = simulate_combinational(circuit, {"A": dividend, "B": divisor})
        if outputs.get("Result") != evaluate_byte_divide(dividend, divisor):
            raise RuntimeError(f"test.si mismatch at tick {tick:#x}")
        stream_vectors += 1
    payload = encode_v15(circuit)
    if decode_v15(payload) != circuit:
        raise RuntimeError("non-native Byte Divide candidate failed v15 round-trip")
    return {
        "gate": circuit.gate,
        "delay": circuit.delay,
        "energy": circuit.energy,
        "full_u8_truth_vectors": vectors,
        "script_vectors": stream_vectors,
        "component_count": len(circuit.components),
        "wire_count": len(circuit.wires),
        "component_kind_counts": {
            str(kind): sum(component.kind == kind for component in circuit.components)
            for kind in sorted({component.kind for component in circuit.components})
        },
        "connectivity": connectivity,
        "layout": {
            "sprite_files": list(layout.sprite_files),
            "alpha_cell_count": layout.alpha_cell_count,
            "component_overlap_cells": [list(point) for point in layout.component_overlap_cells],
            "wire_collisions": [item.__dict__ for item in layout.wire_collisions],
            "wire_interior_pin_contacts": [item.__dict__ for item in layout.wire_interior_pin_contacts],
            "unsupported_component_kinds": list(layout.unsupported_component_kinds),
        },
        "forbidden_native_kinds": forbidden_present,
    }


def write_byte_divide_gate_candidate(
    project_root: Path,
    *,
    sprite_root: Path = DEFAULT_COMPONENT_SPRITE_ROOT,
) -> dict[str, object]:
    root = Path(project_root)
    circuit = build_byte_divide_gate_circuit(root, sprite_root=sprite_root)
    verification = verify_byte_divide_gate_circuit(circuit, sprite_root=sprite_root)
    payload = encode_v15(circuit)
    destination = root / "examples" / LEVEL / "candidate" / "circuit.data"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(payload)
    metadata = {
        "schema": 1,
        "level": LEVEL,
        "title_zh": "除法器",
        "strategy": "restoring division with ordinary word/bit components; no com_div",
        "deployment_status": "非原生研究候选；等待游戏载入验收",
        "forbidden_native_kinds": [31, 32, 108],
        "sha256": sha256(payload).hexdigest(),
        "format_version": 15,
        **verification,
    }
    (destination.parent / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2, default=list) + "\n",
        encoding="utf-8",
    )
    return metadata
